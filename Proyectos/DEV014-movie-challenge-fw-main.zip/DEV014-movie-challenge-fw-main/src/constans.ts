 const token = import.meta.env.VITE_TOKEN_API;
 export {token}
